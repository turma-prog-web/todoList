# todoList

Sistema Web tido como nota parcial para a disciplina de Programmação para Web da FACOM/UFMS
Ministrada por @hsborges

Carlos Alberto de Jesus Pereira Neto
Eduardo Tôrres
Lucca Damico Diniz
Gabriel Rabelo de Melo
Juliano Nepomuceno
